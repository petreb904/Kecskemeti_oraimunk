﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gondoltszam
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program lehetővé teszi, hogy ön kitalálja a gép álltal gondolt számot!");
            Random random = new Random();
            Console.WriteLine("Kérem adja meg, hogy ön szerint melyik számra gondoltam!");
             int szam=random.Next(1,101);
            int gondolt =Convert.ToInt32(Console.ReadLine());
            while (gondolt>0) {

                if (gondolt > szam)
                {
                    Console.WriteLine("Nagyobb számra gondoltam");
                     
                }
                else if (gondolt < szam)
                {
                    Console.WriteLine("kisebb számra gondoltam");
                }
            }
            Console.WriteLine("megfejtés:"+szam);
            Console.ReadKey();
        } 
       
    } 
}
