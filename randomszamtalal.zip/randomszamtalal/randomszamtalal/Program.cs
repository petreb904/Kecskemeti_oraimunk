﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace randomszamtalal
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program random számokat generál");
            Random random = new Random();
            int szam = random.Next(1, 101);
            Console.WriteLine("melyik számra gondoltam?");
            int gondol = 0;
            gondol = Convert.ToInt32(Console.ReadLine());

            while (gondol !=szam)
            {
                if (gondol < szam )
                {
                    Console.WriteLine("Nagyobb számra gondoltam!!");

                }

                else if (gondol > szam)
                {
                    Console.WriteLine("kisebb számra gondoltam");
                }
                Console.WriteLine("A válasz:" + gondol);
                Console.ReadLine();
            }
            Console.WriteLine("erre a számra gondoltam: {0}", gondol );
            }
        }
    }


