﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bekeres
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program két választható szám közül 4 tetszőleges választható alapműveletet segítségével írja ki a megoldást .");
            Console.WriteLine("Adja meg az első számot!");
            string elso=Convert.ToString(Console.ReadLine());
            Console.WriteLine("Adja meg a második számot!");
            string masodik = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Válassz egy műveletet");
            string tarolo=Convert.ToString(Console.ReadLine());

            switch (tarolo)
            {
                case "+":
                    Console.WriteLine("Összead");
                    Console.Write(elso + masodik);
                    break;

                case "-":
                    Console.WriteLine("Kivon");
                    Console.Write(elso - masodik);
                    break;

                case "*":
                    Console.WriteLine("Szoroz");
                    Console.Write (elso * masodik);
                    break; 

                case "/":
                    Console.WriteLine("Oszt");
                    Console.Write(elso / masodik);
                    break;
                  
            }
           

            
            
                



            Console.ReadLine();
        }
    }
}
