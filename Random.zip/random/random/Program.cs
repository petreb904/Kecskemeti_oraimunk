﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace random
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program 28 véletlenszerű számokat állít elő 10 és -10 tartományból. ");
            int[] szamok=new int[28];
            Random rnd = new Random();
            int poz = 0;
            int neg = 0;
            int eredmeny = 0;
            int het = 0;
            int melyik = 0;
            bool igaz=false;
            int nagyobb = -10;
            int kisebb = 10;

            for (int i = 0; i < 28; i++) 
            {
                int szam = rnd.Next(-10,11);
                szamok[i]=szam;
                eredmeny = poz % 2;
                Console.WriteLine(szam);
                if (eredmeny != 0)
                {
                    poz++;
                }

                else
                {
                   neg++;
                }

                if (het == 7) ;
                {
                    het++;
                }

                if (szamok[i] == 0 && igaz == false) 
                {
                    melyik = i;
                    igaz = true;
                }
                
            }
            for (int i=0; i<28; i++) 
            {
                if (kisebb >= szamok[i])
                {
                    kisebb = szamok[i];
                }
                if (nagyobb <= szamok[i])
                {
                    nagyobb = szamok[i];
                }
            }
            Console.WriteLine("Legkisebb szám " +kisebb +" Legnagyobb szám: " + nagyobb);
            Console.WriteLine("hanyadik eleme 0: "+ melyik + "hány eleme hét:  " + het);
            Console.WriteLine("pozitív számok: "+ poz+ "negatív számok:"+ neg);

            Console.ReadKey();
        }
        
    }
}
