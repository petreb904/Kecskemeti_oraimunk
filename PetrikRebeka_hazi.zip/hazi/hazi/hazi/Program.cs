﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hazi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program Olvas be egész számokat egy tömbbe és darbaszőmokat");
            Console.Write("Adja meg a tömb méretét: ");
            int tombi = Convert.ToInt32(Console.ReadLine());



            int[] tomb = new int[tombi];



            for (int i = 0; i < tombi; i++)
            {
                Console.Write("Adja meg a(z) {0}. számot: ", i + 1);
                tomb[i] = Convert.ToInt32(Console.ReadLine());
            }



            Console.Write("Adjon meg a keresett számot: ");
            int keresettSzam = Convert.ToInt32(Console.ReadLine());



            int keresettSzamCount = 0;



            for (int i = 0; i < tombi; i++)
            {
                if (tomb[i] == keresettSzam)
                {
                    keresettSzamCount++;
                }
            }



            Console.WriteLine("{0} ennyiszer szerepel a tömbben: {1} alkalommal.", keresettSzam, keresettSzamCount);



            Console.ReadKey();
        }
    }
}
