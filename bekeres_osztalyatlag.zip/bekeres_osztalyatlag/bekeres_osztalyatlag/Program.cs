﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bekeres_osztalyatlag
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a feladat a diákoknak az átlagját tárolja!");
            Console.WriteLine("Hány diáknak a jegyét szeretnéd tárolni?");
            int diak = Convert.ToInt32(Console.ReadLine()); 
            double[] jegyek = new double[diak]; 
            double atlag = 0; 
            double atlagN = 0; 
            for (int i = 0; i < diak; i++)
            {
                Console.WriteLine("Hányas lett az értékelése");
                double jegy = Convert.ToDouble(Console.ReadLine());
                jegyek[i] = jegy; 
                atlag = atlag + jegy; 
            }
            double eredmeny = atlag / diak; 
            for (int i = 0; i < diak; i++) 
            {
                if (eredmeny < jegyek[i])
                {
                    atlagN++; 
                }
            }
            Console.WriteLine("Ennyi az átlag: {0:0.00}, ", eredmeny);
            Console.WriteLine("Ennyi diák lett annál jobb: ", atlagN);
            Console.ReadLine();
        }
        
    }
    
    
} 
