﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bekeres_osztalyatlag
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double tarol = Convert.ToDouble(Console.ReadLine());
            double bekeres=Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ez a program a tanulók átlagait számolja ki és utánna pedig kiszámolja, hogy hányan voltak jobbak");

            Console.WriteLine("írd be az év végén kapott jegyeid összegét ezek lehetnek: Matek, magyar, irodalom, angol, tesi, környezet, informatika  7DB");
            int diak=Convert.ToInt32(Console.ReadLine());
            double[]jegyek=new double[diak];
            string[]gyerekek=new string[diak];
            Random random = new Random();
            double atlag = 0;



            if ()
            {

            }
           
            



            Console.ReadLine();
        }
        
    }
    
    
} 
