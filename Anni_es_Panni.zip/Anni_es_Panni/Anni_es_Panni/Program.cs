﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Anni_es_Panni
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program, segít eldönteni, hogy kinek kedvez a játék! A program N alkalommal dobja fel a három kockát, és számolja meg, hogy hány esetben volt Anni, és hány esetben volt Panni a nyertes! ");
            int n = Convert.ToInt32(Console.ReadLine());
            Random veletlen = new Random();
            int osszeg = 0;
            int Panni = 0;
            int Anni = 0;
            for (int i =0;i<n;i++)
            {

                int dobas1 = veletlen.Next(0, 6);
                int dobas2 = veletlen.Next(0 ,6);
                int dobas3 = veletlen.Next(0, 6);
                osszeg = dobas1 + dobas2 + dobas3;
                Console.WriteLine();
                if (osszeg>=10)
                {
                    Panni++;
                }
                if (osszeg<10)
                {
                    Anni++;
                }
            }
            Console.WriteLine("Panni:" + Panni + "Anni:" + Anni);
            Console.ReadLine();

        }
    }
}
