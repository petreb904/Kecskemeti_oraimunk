﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oop1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            konyv konyv1=new konyv();
            konyv1.cime = "A kék hajú lány";
            konyv1.kotetek = 1;
            konyv1.oldalszam = 200;
            konyv1.szerzoje = "Dóka Péter";

            Console.WriteLine("Első könyv:");

            Console.WriteLine("Az első könyv cime:"+konyv1.cime);
            Console.WriteLine("Az első könyv kötete:" + konyv1.kotetek);
            Console.WriteLine("Az első könyv oldalszáma:" + konyv1.oldalszam);
            Console.WriteLine("Az első könyv szerzője:" + konyv1.szerzoje);

            

            konyv konyv2= new konyv();
            konyv2.cime = "Szent-Johanna Gimi";
            konyv2.kotetek = 3;
            konyv2.oldalszam = 400;
            konyv2.szerzoje = "Leiner Laura";

            Console.WriteLine("Második könyv:");

            Console.WriteLine("A második könyv cime:" + konyv2.cime);
            Console.WriteLine("A második könyv kötete:" + konyv1.kotetek);
            Console.WriteLine("A második könyv oldalszáma:" + konyv1.oldalszam);
            Console.WriteLine("A második könyv szerzője:" + konyv1.szerzoje);

            Console.ReadLine();
        }
    }
}
