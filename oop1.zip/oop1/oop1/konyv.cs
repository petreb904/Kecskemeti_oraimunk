﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace oop1
{
    internal class konyv
    {
        public string cime;
        public string szerzoje;
        public int oldalszam;
        public int kotetek;
    }
}
